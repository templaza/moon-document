<?php
/**
 * @package   Astroid Framework
 * @author    Astroid Framework Team https://astroidframe.work
 * @copyright Copyright (C) 2024 AstroidFrame.work.
 * @license https://www.gnu.org/licenses/gpl-3.0.html GNU/GPLv3 or Later
*/

//no direct accees
defined('_JEXEC') or die('Restricted Aceess');
use Joomla\CMS\Plugin\CMSPlugin;
class PlgAstroidElementsExample extends CMSPlugin {}